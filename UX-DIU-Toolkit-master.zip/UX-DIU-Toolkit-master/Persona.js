/*******************************************/
/*             PERSONA.JS                  */
/*     Datos para PERSONA TEMPLATE         */   
/*          [DIU] UX Toolkit since 2019    */                        
/*          ver 1.1, 02/2020               */
/*******************************************/
    
/****  README:       */
/****  Modifica los datos para las Personas      */
/****  Las imagenes para  'Photo'  están en carpeta ./photos **/
/****  Si se usan nuevas imágenes se deben añadir a esa carpeta **/
/****  Los valores de rating están entre 1..5 **/
/****  recursos de imágenes:  https://www.vectorstock.com/royalty-free-vectors/vectors-by_zdeneksasek ***/



angular.module("angular", [])
	.controller("controller", ["$scope", function($scope) { 
        $scope.Grupo_ID ="DIU1.ABCDEF";
        $scope.Curso ="2019/20";
		$scope.PersonaIndex = 0;
		$scope.Personas = [
			{		
                
                
                /*************************************/
                /**** PRIMERA PERSONA          *******/
                /*** Cambiar datos             *******/
                /*************************************/
                
                
				Id: 0,
				Name: "Anthoine Walker",
				Photo: "fato_homem.jpg",
				Quote: "Knowledge is king",
				Age: 24,
				Occupation: "Webdesigner",
				Family: "Soltero",
				Location: "Lyon - Francia",
				Character: "Me gusta disfrutar del tiempo y conocer nuevos países y personas. Tech savy.",
				PersonalityTraits: [
					{ Name: "Introvertido/reservado Vs  Extrov/activo ", Value: 5 },
					{ Name: "Realista/práctico  Vs    Intuición/imaginativo", Value: 2 },
					{ Name: "Racional/analitico  Vs   Emocional/impulsivo", Value: 3 },
					{ Name: "Flemático/apático  Vs   Colérico/visceral", Value: 5 }
				], 
				Goals: ["Tener un sítio fijo para mi start-up de webdesign."],
				Frustrations: ["Me gusta la tecnología, pero no que gusta que las personas estan siempre en su móvil.", "Quedar todo el día sentado."],
				Bio: "Soy de Lyon y he venido a Granada para hacer Erasmus+, pero he gustado mucho de la ciudad por eso he venido para aquí vivir, y ahora estoy empezando mi própio negócio de webdesign, y procuro un sítio para quedar trabajando.",
				Tech: [
					{ Name: "TIC/Internet", Value: 5 },
					{ Name: "Movil", Value: 5 },
					{ Name: "RRSS", Value: 3 },
					{ Name: "Software", Value: 5 }
					
				], 
                Contextos: "LLevo un tiempo procurando un lugar para empezar mi start-up y hacer networking",  
				PreferredChannels: [
					{ Name: "Publicidad Tradicional", Value: 5 },
					{ Name: "Online & Social Media", Value: 5 },
					{ Name: "Recomendaciones & sugerencias", Value: 3 },
					{ Name: "Persona confianza (amigos, boca a boca)", Value: 3 }
				]
			},
			{	
                
                /*************************************/
                /**** SEGUNDA PERSONA          *******/
                /*** Cambiar datos             *******/
                /*************************************/
                
                
				Id: 1,
				Name: "Monica Gaztambide",
				Photo: "rapariga.jpeg",
				Quote: "A picture is worth a thousand words",
				Age: 21,
				Occupation: "Empresa de publicidad",
				Family: "No estoy muy conectada con mi familia",
				Location: "Granada-España",
				Character: "Strong, reliable and fearless.",
				PersonalityTraits: [
					{ Name: "Introvertido/reservado Vs  Extrov/activo ", Value: 4 },
					{ Name: "Realista/práctico  Vs    Intuición/imaginativo", Value: 3 },
					{ Name: "Racional/analitico  Vs   Emocional/impulsivo", Value: 2 },
					{ Name: "Flemático/apático  Vs   Colérico/visceral", Value: 2 }
				], 
				Goals: ["Procuro con mi amiga un lugar diferente de nuestra casa para trabajar en nuestra compañía de publicidad"],
				Frustrations: ["Conocer personas falsas.", "Ser robada por personas que van a trabajar en el mismo sítio que yo."],
				Bio: "Segundo año trabajando con mi amiga en una empresa de publicidad. Buscando conocer nuevas personas y experiencias.",
				Tech: [
					{ Name: "TIC/Internet", Value: 4 },
					{ Name: "Mobile", Value: 4 },
					{ Name: "RRSS", Value: 0 },
					{ Name: "Software", Value: 1 }
					
				], 
                Contextos:   "Conocer personas amables y con buenas historias de vida" ,
				PreferredChannels: [
					{ Name: "Publicidad Tradicional (Ads)", Value: 5 },
					{ Name: "Online & Social Media", Value: 4 },
					{ Name: "Recomendaciones & sugerencias", Value: 3 },
					{ Name: "Persona confianza (amigos, boca a boca)", Value: 5 }
				]
			}
		];
		$scope.model = $scope.Personas[0];

	}])