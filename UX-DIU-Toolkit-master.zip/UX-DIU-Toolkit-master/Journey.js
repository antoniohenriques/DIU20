/*******************************************/
/*             JOURNEY.JS                  */
/*     Datos para USER JOURNEY MAP         */   
/*          [DIU] UX Toolkit               */                        
/*          ver 1.0, 2019                  */
/*******************************************/
    
/****  README:       */
/****  Modifica los datos para los Journey Map (uno para cada Persona)  */
/****  Usa los 6 pasos y sigue las instrucciones */   
/****  Las imagenes para  'Photo', 'feelX', 'imaX' están en carpeta ./photos **/
/****  Si se usan nuevas imágenes se deben añadir a esa carpeta **/
/****  Los valores de rating están entre 1..5 **/
/****  recursos de imágenes:  https://www.vectorstock.com/royalty-free-vectors/vectors-by_zdeneksasek ***/




angular.module("angular", [])
	.controller("controller", ["$scope", function($scope) { 
		$scope.Grupo_ID ="DIU1.ABCDEF";
        $scope.Curso ="2019/20";
		$scope.JourneyIndex = 0;
        
        $scope.Journeys = [
			{		
                
                /*************************************/
                /**** PRIMER USER JOURNEY MAP  *******/
                /*** Cambiar datos             *******/
                /*************************************/
                
				Id: 0,
				Name: "Anthoine Walker",
                Photo: "fato_homem.jpg",
    
                /*** PASO #1: INSPIRACION ***/ 
                goal1: "Quiere un sítio para trabajar que no sea su casa.",
                touch1: "movil(notas)",
                feel1: "2",
                con1: "No tener dinero para hacer coworking",
                ima1: "cartoon-crying.png",
				
                /*** PASO #2: DECICION ***/ 
                goal2: "Empezar a procurar en la web sitios para hacer coworking",
                touch2: "Computador",
                feel2: "4",
                con2: "No encontrar donde hacer coworking",
                ima2: "cartoon-PChappy.png",
                
                /*** PASO #3: ACTUA ***/ 
                
                goal3: "Encuentra erranT y decide hablar con los dueños.",
                touch3: "ordenador",
                feel3: "4",
                con3: "Tiene miedo que las personas no sean amables. ",
                ima3: "cartoon-PChappy.png",
                
                /*** PASO #4: OBSERVA ***/ 
                
                goal4: "Hablado con los dueños de erranT",
                touch4: "móvil",
                feel4: "4",
                con4: "-",
                ima4: "cartoon-phoning.png",
                
                 /*** PASO #5: ANALIZA ***/ 
                
                goal5: "Analiza entre erranT y quedarse en su casa trabajando.",
                touch5: "móvil",
                feel5: "5",
                con5: "No conseguir decidir entre erranT o quedarse en casa.",
                ima5: "cartoon-thinking.png",
                
                
                /*** PASO #6: CONCLUSION ***/ 
                
                goal6: "Decide ir a trabajar en erranT",
                touch6: "móvil",
                feel6: "5",
                con6: "Miedo que no pueda pagar por mucho tiempo ",
                ima6: "cartoon-shaking.png",
                
			},
			{	
                /*************************************/
                /**** SEGUNDO USER JOURNEY MAP *******/
                /***      Cambiar datos        *******/
                /*************************************/
                
				Id: 1,
				Name: "Monica Gaztambide",
                Photo: "rapariga.jpeg",
                
				 /*** PASO #1: INSPIRACION ***/ 
                goal1: "Quiere encontrar donde trabajar con su amiga",
                touch1: "casa",
                feel1: "3",
                con1: "No conseguir encontrar donde trabajar con su amiga.",
                ima1: "cartoon-awaking.png",
                
                /*** PASO #2: DECICION ***/ 
                goal2: "Deciden procurar por un coworking space en Granada",
                touch2: "Casa",
                feel2: "3",
                con2: "No conseguir encontrar un espacio coworking en Granada.",
                ima2: "cartoon-planning.png",
                
                /*** PASO #3: ACTUA ***/ 
                
                goal3: "Encuentran erranT y más espacios de coworking en Granada",
                touch3: "móvil",
                feel3: "3",
                con3: "No conseguir decidir entre erranT y otros espacios.",
                ima3: "cartoon-phone-sitting.png",
                
                /*** PASO #4: OBSERVA ***/ 
                
                goal4: "Deciden hablar con los dueños de erranT a ver como es el espacio y las personas.",
                touch4: "móvil",
                feel4: "4",
                con4: "No les guste en espacio o las personas que trabajan en erranT.",
                ima4: "cartoon-speaking.png",
                
                 /*** PASO #5: ANALIZA ***/ 
                
                goal5: "Analiza con su amiga cual es la mejor cosa a hacer.",
                touch5: "casa",
                feel5: "5",
                con5: "Que tengamos diferentes decisiones.",
                ima5: "cartoon-thinking.png",
                
                
                /*** PASO #6: CONCLUSION ***/ 
                
                goal6: "Deciden reservar un espacio en erranT",
                touch6: "móvil",
                feel6: "5",
                con6: "Que no les guste las personas que trabajan en es mismo espacio que nosotras.",
                ima6: "cartoon-teamthinking.png",
                
                
                
			}
		];
        
		$scope.model = $scope.Journeys[0];

	}])



